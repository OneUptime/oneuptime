class LogType:
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
